﻿using System;
using System.Data.SqlClient;
using System.Web.UI;

namespace Buoi_10___Ngay_5_thang_7
{
    public partial class MatHang : Page
    {
        // Connection string to use AttachDbFilename
        string conn = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=E:\.NET\TMDT\BUOI 10 - NGAY 5 THANG 7\BUOI 10 - NGAY 5 THANG 7\APP_DATA\DATABASE1.MDF;Integrated Security=True;Connect Timeout=30";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.IsPostBack) return; // Load lại trang khi trang chưa được load

            if (Context.Items["ml"] != null)
            {
                string maloai = Context.Items["ml"].ToString();
                using (SqlConnection con = new SqlConnection(conn))
                {
                    try
                    {
                        con.Open();
                        string query = "SELECT * FROM matHang WHERE maloai = @maloai";
                        SqlCommand command = new SqlCommand(query, con);
                        command.Parameters.AddWithValue("@maloai", maloai);

                        SqlDataReader reader = command.ExecuteReader();
                        GridView1.DataSource = reader;
                        GridView1.DataBind();
                    }
                    catch (SqlException err)
                    {
                        Response.Write("<b>Lỗi: </b>" + err.Message + "<p/>");
                    }
                }
            }
        }
    }
}
