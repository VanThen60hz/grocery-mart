﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;

namespace Buoi_10___Ngay_5_thang_7
{
    public partial class LoaiHang_DropDownList : Page
    {
        // Updated connection string to use AttachDbFilename
        string cnn = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=E:\.NET\TMDT\BUOI 10 - NGAY 5 THANG 7\BUOI 10 - NGAY 5 THANG 7\APP_DATA\DATABASE1.MDF;Integrated Security=True;Connect Timeout=30";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.IsPostBack) return; // Load lại trang khi trang chưa được load
            string q1 = "select * from LoaiHang";
            try
            {
                using (SqlConnection connection = new SqlConnection(cnn))
                {
                    SqlDataAdapter da = new SqlDataAdapter(q1, connection);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    this.DropDownList1.DataSource = dt;
                    this.DropDownList1.DataTextField = "TenLoai";
                    this.DropDownList1.DataValueField = "MaLoai";
                    this.DropDownList1.DataBind();
                }
            }
            catch (SqlException ex)
            {
                Response.Write(ex.Message);
            }
        }
    }
}
