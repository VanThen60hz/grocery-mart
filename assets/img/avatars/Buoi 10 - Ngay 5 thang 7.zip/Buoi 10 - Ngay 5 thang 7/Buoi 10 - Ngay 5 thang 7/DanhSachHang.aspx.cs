﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;

namespace Buoi_10___Ngay_5_thang_7
{
    public partial class DanhSachHang : Page
    {
        // Updated connection string to use AttachDbFilename
        string cnn = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=E:\.NET\TMDT\BUOI 10 - NGAY 5 THANG 7\BUOI 10 - NGAY 5 THANG 7\APP_DATA\DATABASE1.MDF;Integrated Security=True;Connect Timeout=30";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.IsPostBack) return; // Load lại trang khi trang chưa được load
            string q1 = "select * from LoaiHang";
            try
            {
                using (SqlConnection connection = new SqlConnection(cnn))
                {
                    SqlDataAdapter da = new SqlDataAdapter(q1, connection);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    this.RadioButtonList1.DataSource = dt;
                    this.RadioButtonList1.DataTextField = "TenLoai";
                    this.RadioButtonList1.DataValueField = "MaLoai";
                    this.RadioButtonList1.DataBind();
                }
            }
            catch (SqlException ex)
            {
                Response.Write(ex.Message);
            }
        }

        protected void RadioButtonList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string MaLoai = this.RadioButtonList1.SelectedItem.Value;
            Context.Items["ml"] = MaLoai;
            Server.Transfer("MatHang.aspx");
        }
    }
}
